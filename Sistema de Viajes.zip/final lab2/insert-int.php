<!-- Comienza código: insert.php -->
<?PHP
require_once ("./ludb.php");
$id_usuario = $_GET["id_usuario"];
$id_paquetes = $_GET["id_paquetes"];

$query = "INSERT 
            INTO INTERESES(
                id_intereses, 
                fecha_intereses, 
                id_usuario, 
                id_paquetes)
            VALUE (
                NULL, 
                now(), 
                '$id_usuario',
                '$id_paquetes');";

//echo $query;



if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Registro insertado")</script>';
  $id_usuario = $_GET["id_usuario"];
  include ("./crud-int.php");
  } else {
    echo "Error: " . $query . "<br>" . $DB_conn->error;
    exit;
  }

 /*if(!$rs {
    echo "Error: No se pudo insertar en la base de datos MySQL." . NEWLINE;
    echo "Nro de error: " . mysqli_connect_errno() . NEWLINE;
    echo "Mensaje de depuración: " . mysqli_connect_error() . NEWLINE;
    exit;
 }*/

 $_SESSION['message'] = "Éxito: se guardaron correctamente los datos en la base.";
 $_SESSION['message_type'] = "success";

header("Location: ./crud-int.php");


?>