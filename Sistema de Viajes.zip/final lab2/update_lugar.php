<!-- Comienza código: update.php -->
<?PHP
include ("./ludb.php");

if(isset($_POST['update'])) {    
    $id_lugar        = $_POST["id_lugar"];
    $descripcion       = $_POST["descripcion"];
    $nombre       = $_POST["nombre"];

    $query = "UPDATE LUGARES SET    nombre= '$nombre',
                                    descripcion = '$descripcion'
                             WHERE  id_lugar = $id_lugar";

  if ($DB_conn->query($query) === TRUE) {
    echo '<script>alert("Registro actualizado")</script>';
    include ("./crud_lugar.php");
  } else {
    echo "Error updating record: " . $DB_conn->error;
    exit;
  }                         
  
    $_SESSION['message'] = "Éxito: se actualizaron correctamente los datos del registro en la base.";
    $_SESSION['message_type'] = "primary";
   
    header("Location: ./crud_lugar.php");
}

?>
