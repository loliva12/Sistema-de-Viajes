<!-- Comienza código: read.php -->
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID Usuario</th>
            <th>Nombre de Usuario</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>E-mail</th>
            <th>Teléfono</th>
            <th>Nacimiento</th>
            <th>Contraseña</th>
            <th>Empleado</th>
        </tr>
    </thead>
    <tbody>
        <?PHP
            $query = "SELECT * FROM USUARIOS";
            $result = mysqli_query($DB_conn, $query);

            while($register = mysqli_fetch_array($result)) { ?>
                <tr onclick="document.location = './edit-cliente.php?id_usuario=<?PHP echo $register['id_usuario']; ?>'">
                    <td><?PHP echo $register['id_usuario']; ?></td>
                    <td><?PHP echo $register['username']; ?></td>
                    <td><?PHP echo $register['nombre']; ?></td>
                    <td><?PHP echo $register['apellido']; ?></td>
                    <td><?PHP echo $register['email']; ?></td>
                    <td><?PHP echo $register['telefono']; ?></td>
                    <td><?PHP echo $register['nacimiento']; ?></td>
                    <td><?PHP echo $register['contrasenia']; ?></td>
                    <td><?PHP echo $register['empleado']; ?></td>
                    <td>

                        <a href="./edit-cliente.php?id_usuario=<?PHP echo $register['id_usuario']; ?>" class="btn btn-success" title="Editar el registro <?PHP echo $register['id_usuario']; ?>">
                            <!-- icono para editar -->
                            <i class="fas fa-user-edit"></i>
                        </a>
                        <a href="./delete-cliente.php?id_usuario=<?PHP echo $register['id_usuario']; ?>" class="btn btn-danger" title="Borrar el registro <?PHP echo $register['id_usuario']; ?>">
                            <!-- icono para eliminar -->
                            <i class="fas fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>
            <?PHP } ?>
    </tbody>
</table>
