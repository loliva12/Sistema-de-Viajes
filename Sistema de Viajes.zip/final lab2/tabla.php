 <?PHP

require_once ("./ludb.php");

$sql = "SELECT P.*, L.nombre nom_lug
          FROM PAQUETES P,
               LUGARES L 
        WHERE P.id_lugar = L.id_lugar";

$result = mysqli_query($DB_conn, $sql);

if ($result->num_rows > 0) {
    $ligne = $result;
  } else {
    echo "0 results";
  }
  $DB_conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Trabajo Final" />
        <meta name="author" content="Lucia Oliva y Sabrina Vicente" />
        <title>PAQUETES</title>
        <link rel="stylesheet" href="./Inicio.css">
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    </meta>
</head>

    <body class="sb-nav-fixed">
    <div id="container-header">
        <header>
            <div id="conteiner-header-title">
                <h1>Paquetes de Viaje</h1>
            </div> 
        </header>
    </div>        
    <div id="conteiner-header-foto">
        <img src="Imagenes/logo.png" alt="Logo" width=300>
    </div>
              <!--<div id="layoutSidenav">
            <div id="layoutSidenav_content">-->
                <!--<main>-->
                    <div class="container-fluid px-4">
                        <h2 class="mt-4">LISTA DE PAQUETES</h2>
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                PAQUETES
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="table table-striped" style="width:100%"> 
                                    <thead>
                                        <tr>
                                            <th>NOMBRE DEL PAQUETE</th>
                                            <th>PRECIO</th>
                                            <th>FECHA IDA</th>
                                            <th>FECHA REGRESO</th>
                                            <th>TRANSPORTE</th>
                                            <th>NOMBRE ALOJAMIENTO</th>
                                            <th>EXCURSIONES</th>
                                            <th>CLASES</th>
                                            <th>LUGAR</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php 
                                                        foreach ($ligne as $list) {
                                                ?>
                                                <tr>
                                                    <td><?php echo stripslashes($list['nombre']); ?></td>
                                                    <td><?php echo stripslashes($list['precio']) ; ?></td>
                                                    <td><?php echo stripslashes($list['fecha_ida']); ?></td>
                                                    <td><?php echo stripslashes($list['fecha_vuelta']); ?></td>
                                                    <td><?php echo stripslashes($list['transporte']); ?></td>
                                                    <td><?php echo stripslashes($list['nombre_alojamiento']); ?></td>
                                                    <td><?php echo stripslashes($list['excursiones']); ?></td>
                                                    <td><?php echo stripslashes($list['clase']); ?></td>
                                                    <td><?php echo stripslashes($list['nom_lug']); ?></td>

                                                    <td>
                                                        <a href="./insert-int.php?id_usuario=<?PHP echo $id_usuario?>&id_paquetes=<?PHP echo $list['id_paquetes']?>" class="btn btn-success" title="Me Gusta">
                                                         <i class="far fa-thumbs-up"></i>
                                                        </a>
                                                        <a href="./delete-int.php?id_usuario=<?PHP echo $id_usuario?>&id_paquetes=<?PHP echo $list['id_paquetes']?>" class="btn btn-danger" title="Borrar Interes">
                                                        <!-- icono para eliminar -->
                                                        <i class="fas fa-trash-alt"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php
                                            
                                            }
                                        ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <!--</main>-->
                    <div class="py-4 bg-light mt-auto">
                        <div class="container-fluid px-4">
                            <div class="d-flex align-items-center justify-content-between small">

                                <form action="./index.html" method="POST">
                                    <input type="submit" class="btn btn-primary" name="create" value="VOLVER">
                                </form>
                                
                            </div>
                        </div>
                    </div>
            <!--</div>-->
        <!--</div>-->
        <?php include('./footer-tabla.php'); ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
