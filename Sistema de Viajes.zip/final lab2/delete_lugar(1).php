<!-- Comienza código: delete.php -->
<?PHP

require_once ("./ludb.php");

if($_GET['id_lugar']) {
    $id_lugar = $_GET['id_lugar'];
    $query = "DELETE FROM LUGARES
                WHERE id_lugar = $id_lugar";

if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Borrado exitoso")</script>';
  include ("./crud_lugar.php");
  } else {
    echo "Error deleting record: " . $DB_conn->error;
    exit;
  }            
    
    header("Location: ./crud_lugar.php");
}

?>


