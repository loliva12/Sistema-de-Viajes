<!-- Comienza código: delete.php -->
<?PHP

require_once ("./ludb.php");

if($_GET['id_paquetes']) {
    $id_paquetes = $_GET['id_paquetes'];
    $query = "DELETE FROM PAQUETES
                WHERE id_paquetes = $id_paquetes";

if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Borrado exitoso")</script>';
  include ("./crud-paq.php");
  } else {
    echo "Error deleting record: " . $DB_conn->error;
    exit;
  }            
    
    header("Location: ./crud-paq.php");
}

?>


