<!-- Comienza código: update.php -->
<?PHP
include ("./ludb.php");

if(isset($_POST['update'])) {    
    $id_usuario        = $_POST["id_usuario"];
    $username       = $_POST["username"];
    $nombre       = $_POST["nombre"];
    $apellido    = $_POST["apellido"];
    $email       = $_POST["email"];
    $telefono      = $_POST["telefono"];
    $nacimiento      = $_POST["nacimiento"];
    $contrasenia       = $_POST["contrasenia"];
    $empleado       = $_POST["empleado"];


    
    $query = "UPDATE USUARIOS SET    username= '$username',
                                    nombre = '$nombre',
                                    apellido = '$apellido',
                                    email = '$email',
                                    telefono = '$telefono',
                                    nacimiento = '$nacimiento',
                                    contrasenia = '$contrasenia',
                                    empleado = '$empleado'
                             WHERE  id_usuario = $id_usuario";

  if ($DB_conn->query($query) === TRUE) {
    echo '<script>alert("Registro actualizado")</script>';
    include ("./crud-cliente.php");
  } else {
    echo "Error updating record: " . $DB_conn->error;
    exit;
  }                         
  
    $_SESSION['message'] = "Éxito: se actualizaron correctamente los datos del registro en la base.";
    $_SESSION['message_type'] = "primary";
   
    header("Location: ./crud-cliente.php");
}

?>
