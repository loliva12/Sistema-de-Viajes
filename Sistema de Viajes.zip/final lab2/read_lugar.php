<!-- Comienza código: read.php -->
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID lugar</th>
            <th>Nombre</th>
            <th>Descripción</th>
        </tr>
    </thead>
    <tbody>
        <?PHP
            $query = "SELECT * FROM LUGARES";
            $result = mysqli_query($DB_conn, $query);

            while($register = mysqli_fetch_array($result)) { ?>
                <tr onclick="document.location = './edit_lugar.php?id=<?PHP echo $register['id_lugar']; ?>'">
                    <td><?PHP echo $register['id_lugar']; ?></td>
                    <td><?PHP echo $register['nombre']; ?></td>
                    <td><?PHP echo $register['descripcion']; ?></td>
                    <td>

                        <a href="./edit_lugar.php?id_lugar=<?PHP echo $register['id_lugar']; ?>" class="btn btn-success" title="Editar el registro <?PHP echo $register['id_lugar']; ?>">
                            <!-- icono para editar -->
                            <i class="fas fa-user-edit"></i>
                        </a>
                        <a href="./delete_lugar.php?id_lugar=<?PHP echo $register['id_lugar']; ?>" class="btn btn-danger" title="Borrar el registro <?PHP echo $register['id_lugar']; ?>">
                            <!-- icono para eliminar -->
                            <i class="fas fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>
            <?PHP } ?>
    </tbody>
    
</table>

