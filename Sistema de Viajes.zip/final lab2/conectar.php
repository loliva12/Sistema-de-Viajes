<?php
require_once ("./ludb.php");
?>

<?php 
//session_start(); 
$name        = $_POST["name"];
$password      =$_POST["password"];
$query = "SELECT id_usuario, empleado
            FROM USUARIOS 
           where username = '$name'
             and contrasenia = '$password'";
$result = mysqli_query($DB_conn, $query);

if (mysqli_num_rows($result) > 0) {

  while($row = mysqli_fetch_assoc($result)) {
      if ($row["empleado"] =='N'){
        $id_usuario = $row["id_usuario"];
        include ("./tabla.php");                    
      }else{
        include ("./empleado.html");
      }
  }
} else {
  echo '<script>alert("Usuario o contraseña inválida, pruebe nuevamente o cree uno nuevo")</script>';
  include ("./index.html");
}
?>
