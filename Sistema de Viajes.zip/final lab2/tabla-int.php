<?PHP

require_once ("./ludb.php");

$query = "SELECT P.nombre, count(1) cantidad
            FROM PAQUETES P,
                 INTERESES I 
            WHERE P.id_paquetes = I.id_paquetes
         GROUP BY P.nombre
         ORDER BY COUNT(1) DESC";

$result = mysqli_query($DB_conn, $query);
if ($result->num_rows > 0) {
    $ligne = $result;
  } else {
    echo "0 results";
  }
  $DB_conn->close();
?>


<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Trabajo Final" />
        <meta name="author" content="Lucia Oliva y Sabrina Vicente" />
        <title>PAQUETES</title>
        <link rel="stylesheet" href="./Inicio.css">
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    </head>

    <body class="sb-nav-fixed">
    <div id="container-header">
        <header>
            <div id="conteiner-header-title">
                <h1>Paquetes de Viaje</h1>
            </div>
            
        </header>
    </div>        
    <div id="conteiner-header-foto">
        <img src="Imagenes/logo.png" alt="Logo" width=300>
    </div>
             <!-- <div id="layoutSidenav">
            <div id="layoutSidenav_content">-->
                <!--<main>-->
                    <div class="container-fluid px-4">
                        <h2 class="mt-4">RANKING DE INTERESES</h2>
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                INTERESES
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="table table-striped" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>NOMBRE</th>
                                            <th>VOTOS</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php 
                                                        foreach ($ligne as $list) {
                                                ?>
                                                <tr>
                                                    <td><?php echo stripslashes($list['nombre']); ?></td>
                                                    <td><?php echo stripslashes($list['cantidad']) ; ?></td>
                                                </tr>
                                                <?php
                                            
                                            }
                                        ?>
                                        </tr>
                                    </tbody>
                                </table>
                                
                            </div>
                        </div>
                    </div>
                <!--</main>-->
                    <div class="py-4 bg-light mt-auto">
                        <div class="container-fluid px-4">
                            <div class="d-flex align-items-center justify-content-between small">
                                <form action="./empleado.html" method="POST">
                                    <input type="submit" class="btn btn-primary" name="create" value="VOLVER">
                                </form>
                            </div>
                        </div>
                    </div>
            <!--</div>-->
       <!-- </div>-->
       <?php include('./footer-tabla.php'); ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
