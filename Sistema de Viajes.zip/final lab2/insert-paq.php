<!-- Comienza código: insert.php -->
<?PHP
require_once ("./ludb.php");

$nombre       = $_POST["nombre"];
$precio       = $_POST["precio"];
$fecha_ida    = $_POST["fecha_ida"];
$fecha_vuelta     = $_POST["fecha_vuelta"];
$transporte      = $_POST["transporte"];
$nombre_alojamiento      = $_POST["nombre_alojamiento"];
$excursiones      = $_POST["excursiones"];
$clase      = $_POST["clase"];
$id_lugar      = $_POST["id_lugar"];

$query = "INSERT 
            INTO PAQUETES(
                id_paquetes,
                nombre, 
                precio, 
                fecha_ida, 
                fecha_vuelta,
                transporte,
                nombre_alojamiento,
                excursiones,
                clase,
                id_lugar)
            VALUE (
                NULL, 
                '$nombre',
                '$precio', 
                '$fecha_ida',
                '$fecha_vuelta',
                '$transporte',
                '$nombre_alojamiento',
                '$excursiones',
                '$clase',
                '$id_lugar');";

//echo $query;



if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Registro insertado")</script>';
  include ("./crud-paq.php");
  } else {
    echo "Error: " . $query . "<br>" . $DB_conn->error;
    exit;
  }

 /*if(!$rs {
    echo "Error: No se pudo insertar en la base de datos MySQL." . NEWLINE;
    echo "Nro de error: " . mysqli_connect_errno() . NEWLINE;
    echo "Mensaje de depuración: " . mysqli_connect_error() . NEWLINE;
    exit;
 }*/

 $_SESSION['message'] = "Éxito: se guardaron correctamente los datos en la base.";
 $_SESSION['message_type'] = "success";

header("Location: ./crud-paq.php");


?>