
    <footer>
        <div id="container-footer">
            <hr>
            <hr> 
            <h3>CONTACTANOS</h3>
            <p>Email: paquetesdeviaje@gmail.com</p>
            <p>Ubicacion: Cordoba, Argentina</p>    
            <p>Telefono: 351-5477890</p>
        </div>
    </footer>
