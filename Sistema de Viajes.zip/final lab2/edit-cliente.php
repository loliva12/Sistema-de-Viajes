<!-- Comienza código: edit.php -->
<?PHP

include("./ludb.php");

if(isset($_GET['id_usuario'])) {
    $id_usuario = $_GET['id_usuario'];
    $query = "SELECT * FROM USUARIOS
                WHERE id_usuario = $id_usuario";
    $result = mysqli_query($DB_conn, $query);
    if(mysqli_num_rows($result) == 1) {
        $register = mysqli_fetch_array($result);
        $username = $register['username'];
        $nombre = $register['nombre'];
        $apellido = $register['apellido'];
        $email = $register['email'];
        $telefono = $register['telefono'];
        $nacimiento = $register['nacimiento'];
        $contrasenia = $register['contrasenia'];
        $empleado = $register['empleado'];
    }
}

?>

<?php include ("./header-cliente.php"); ?>

<div class="container p-4">
    <div class="row">
        <div class="col-4 mx-auto">
            <div class="card" card-body>
            <div class="card-header">Editar Persona</div>
                <form action="./update-cliente.php" method="POST">
                    <input type="hidden" name="id_usuario" value="<?PHP echo $id_usuario ?>">
                    <div class="form-group">
                    <div class="mb-3">
                            <label for="username">Username</label>
                            <input type="text"  name="username" class="form-control" value="<?PHP echo $username ?>" placeholder="Escriba el nombre de usuario" autofocus required>
                        </div>
                        <div class="mb-3">
                            <label for="nombre">Nombre</label>
                            <input type="text"  name="nombre" class="form-control" value="<?PHP echo $nombre ?>" placeholder="Escriba el nombre" autofocus required>
                        </div>
                    
                        <div class="mb-3">
                            <label for="apellido">Apellido</label>
                            <input type="text" name="apellido" class="form-control" value="<?PHP echo $apellido ?>"  required>
                        </div>
                        <div class="mb-3">
                            <label for="email">E-mail</label>
                            <input type="email" name="email" class="form-control" value="<?PHP echo $email ?>">
                        </div>
                        <div class="mb-3">
                            <label for="telefono">Teléfono</label>
                            <input type="number" name="telefono" class="form-control" value="<?PHP echo $telefono ?>">
                        </div>
                    
                        <div class="mb-3">
                            <label for="nacimiento">Nacimiento</label>
                            <input type="date" name="nacimiento" class="form-control" value="<?PHP echo $nacimiento ?>">
                        </div>
                        <div class="mb-3">
                            <label for="contrasenia">Contraseña</label>
                            <input type="password" name="contrasenia" class="form-control" value="<?PHP echo $contrasenia ?>">
                        </div>
                        <div class="mb-3">
                            <label for="empleado">Empleado/Cliente</label>
                            <input type="text" name="empleado" class="form-control" value="<?PHP echo $empleado ?>">
                        </div>
                    </div>
                    <input type="submit" class="btn btn-success" name="update" value="Actualizar">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include ("./footer-cliente.php"); ?>