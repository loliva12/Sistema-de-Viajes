<!-- Comienza código: insert.php -->
<?PHP
require_once ("./ludb.php");

$username       = $_POST["username"];
$nombre       = $_POST["nombre"];
$apellido    = $_POST["apellido"];
$email      = $_POST["email"];
$telefono     = $_POST["telefono"];
$nacimiento      = $_POST["nacimiento"];
$contrasenia      = $_POST["contrasenia"];
$empleado      = $_POST["empleado"];

$query1 = "SELECT id_usuario, empleado
            FROM USUARIOS 
           where username = '$username'";
$result1 = mysqli_query($DB_conn, $query1);

if (mysqli_num_rows($result1) > 0) {
  echo '<script>alert("El usuario ya esta registrado, ingrese uno nuevo")</script>';
  include ("./crud-cliente.php");
}else{
  $query = "INSERT 
              INTO USUARIOS(
                  id_usuario, 
                  username,
                  nombre, 
                  apellido,
                  email, 
                  telefono,
                  nacimiento,
                  contrasenia,
                  empleado)
              VALUE (
                  NULL, 
                  '$username', 
                  '$nombre', 
                  '$apellido',
                  '$email',
                  '$telefono',
                  '$nacimiento',
                  '$contrasenia',
                  '$empleado');";

  if ($DB_conn->query($query) === TRUE) {
    echo '<script>alert("Registro insertado")</script>';
    include ("./crud-cliente.php");
    } else {
      echo "Error: " . $query . "<br>" . $DB_conn->error;
      exit;
   }

  $_SESSION['message'] = "Éxito: se guardaron correctamente los datos en la base.";
  $_SESSION['message_type'] = "success";
}
header("Location: ./crud-cliente.php");


?>