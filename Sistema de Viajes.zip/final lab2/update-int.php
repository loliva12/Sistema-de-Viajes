<!-- Comienza código: update.php -->
<?PHP
include ("./db.php");

if(isset($_POST['update'])) {    
    $Id        = $_POST["Id"];
    $nombre       = $_POST["nombre"];
    $apellido    = $_POST["apellido"];
    $telefono      = $_POST["telefono"];
    $mail      = $_POST["mail"];

    $query = "UPDATE usuarios SET    nombre= '$nombre',
                                    apellido = '$apellido',
                                    telefono = '$telefono',
                                    mail = '$mail'
                             WHERE  Id = $Id";

  if ($DB_conn->query($query) === TRUE) {
    echo "Record updated successfully";
  } else {
    echo "Error updating record: " . $DB_conn->error;
    exit;
  }                         
  
    $_SESSION['message'] = "Éxito: se actualizaron correctamente los datos del registro en la base.";
    $_SESSION['message_type'] = "primary";
   
    header("Location: ./crud.php");
}

?>
