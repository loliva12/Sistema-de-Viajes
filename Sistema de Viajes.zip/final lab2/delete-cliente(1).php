<!-- Comienza código: delete.php -->
<?PHP

require_once ("./ludb.php");

if($_GET['id_usuario']) {
    $id_usuario = $_GET['id_usuario'];
    $query = "DELETE FROM USUARIOS
                WHERE id_usuario = $id_usuario";

if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Borrado exitoso")</script>';
  include ("./crud-cliente.php");
  } else {
    echo "Error deleting record: " . $DB_conn->error;
    exit;
  }            
    
    header("Location: ./crud-cliente.php");
}

?>


