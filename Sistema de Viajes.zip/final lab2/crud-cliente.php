<?php require_once ("./ludb.php"); ?>

<?php include ("./header-cliente.php"); ?>

<main>
    <div class="container p-4">
        <div class="row">
            <div class="col-4"> 
                <?php include ("./create-cliente.php"); ?>
            </div>
            <div class="col-8">
                <?php include ("./read-cliente.php"); ?>
            </div>
        </div>
    </div>
    </main>

<?php include ("./footer-cliente.php"); ?>
