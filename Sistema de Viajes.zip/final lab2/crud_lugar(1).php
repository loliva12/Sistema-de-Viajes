<?php require_once ("./ludb.php"); ?>

<?php include ("./header_lugar.php"); ?>
<head>
    <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Trabajo Final" />
        <meta name="author" content="Lucia Oliva y Sabrina Vicente" />
        <link rel="stylesheet" href="./Inicio.css">
    </meta>
</head>

<main>
    <div class="container p-4">
        <div class="row">
            <div class="col-4"> 
                <?php include ("./create_lugar.php"); ?>
            </div>
            <div class="col-8">
                <?php include ("./read_lugar.php"); ?>
            </div>
        </div>
    </div>
    </main>

<?php include ("./footer_lugar.php"); ?>
