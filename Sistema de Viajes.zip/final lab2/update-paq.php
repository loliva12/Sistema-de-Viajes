<!-- Comienza código: update.php -->
<?PHP
include ("./ludb.php");

if(isset($_POST['update'])) {    
    $id_paquetes        = $_POST["id_paquetes"];
    $nombre       = $_POST["nombre"];
    $precio       = $_POST["precio"];
    $fecha_ida    = $_POST["fecha_ida"];
    $fecha_vuelta      = $_POST["fecha_vuelta"];
    $nombre_alojamiento      = $_POST["nombre_alojamiento"];
    $excursiones      = $_POST["excursiones"];
    $clase      = $_POST["clase"];
    $id_lugar      = $_POST["id_lugar"];

    $query = "UPDATE PAQUETES SET   nombre= '$nombre', 
                                    precio= '$precio',
                                    fecha_ida = '$fecha_ida',
                                    fecha_vuelta = '$fecha_vuelta',
                                    nombre_alojamiento = '$nombre_alojamiento',
                                    excursiones = '$excursiones',
                                    clase = '$clase',
                                    id_lugar = '$id_lugar'
                             WHERE  id_paquetes = $id_paquetes";

  if ($DB_conn->query($query) === TRUE) {
    echo '<script>alert("Registro actualizado")</script>';
    include ("./crud-paq.php");
  } else {
    echo "Error updating record: " . $DB_conn->error;
    exit;
  }                         
  
    $_SESSION['message'] = "Éxito: se actualizaron correctamente los datos del registro en la base.";
    $_SESSION['message_type'] = "primary";
   
    header("Location: ./crud-paq.php");
}

?>
