<!-- Comienza código: create.php -->
<?PHP
//session_start();
$message = $_SESSION['message']; 
$message_type = $_SESSION['message_type']; 
$query1 = "SELECT id_lugar,nombre 
             FROM LUGARES";
$result1 = mysqli_query($DB_conn, $query1);
if(isset($message)) { ?>
    <div class="alert alert-<?PHP echo $message_type ?> alert-dismissible fade show" role="alert">
    <p><?PHP echo $message; ?></p>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

<?PHP 
    session_unset(); 
} ?>

<div class="card card-body">
    <div class="card-header">Crear Paquete</div>
    <form action="./insert-paq.php" method="POST">
        <div class="form-group">
        <div class="mb-3">
                <label for="nombre">Nombre del Paquete</label>
                <input type="text" id="nombre" name="nombre" class="form-control" placeholder="Ingrese nombre del paquete" autofocus required>
            </div>
            <div class="mb-3">
                <label for="precio">Precio</label>
                <input type="number" id="precio" name="precio" class="form-control" placeholder="Ingrese el precio" autofocus required>
            </div>
        
            <div class="mb-3">
                <label for="fecha_ida">Fecha de Ida</label>
                <input type="date" name="fecha_ida" class="form-control" placeholder="Ingrese la fecha de partida" autofocus required>
            </div>
        
            <div class="mb-3">
            <label for="fecha_vuelta">Fecha de Regreso</label>
                <input type="date" name="fecha_vuelta" class="form-control" placeholder="Ingrese la fecha de regreso" autofocus required>
            </div>
        
            <div class="mb-3">
                <label for="transporte">Transporte</label>
                <input type="text" name="transporte" class="form-control" placeholder="Ingrese S/N (S=si/ N=no)" autofocus>
            </div>
            <div class="mb-3">
                <label for="nombre_alojamiento">Nombre de alojamiento</label>
                <input type="text" name="nombre_alojamiento" class="form-control" placeholder="Ingrese el nombre del alojamiento" autofocus>
            </div>
            <div class="mb-3">
                <label for="excursiones">Excursiones</label>
                <input type="text" name="excursiones" class="form-control" placeholder="Ingrese excurciones" autofocus>
            </div>
            <div class="mb-3">
            <label for="clase">Tipos de clase</label>
                        <select id="clase" name="clase">
                            <optgroup>
                                <option value="oro">Oro</option>
                                <option value="plata">Plata</option>
                                <option value="bronce">Bronce</option>
                            </optgroup>
                        </select>    
            </div>
            <div class="mb-3">
            <label for="id_lugar">Lugares</label>
            <input type="number" name="id_lugar" type="list" list="id_lugar">
                <datalist id="id_lugar">
                <?php
                    while($fila1 = $result1->fetch_assoc()):
                        $id_lugar = $fila1['id_lugar'];
                        echo '<option value="'.$fila1[id_lugar].'">'.$fila1[nombre].'</option>';
                    endwhile; 
                ?>
            </detalist> 
            </div>
        </div>
        <input type="submit" class="btn btn-success" name="create" value="Crear">
    </form>
</div>
