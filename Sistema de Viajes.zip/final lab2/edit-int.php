<!-- Comienza código: edit.php -->
<?PHP

include("./db.php");

if(isset($_GET['Id'])) {
    $Id = $_GET['Id'];
    $query = "SELECT * FROM usuarios
                WHERE Id = $Id";
    $result = mysqli_query($DB_conn, $query);
    if(mysqli_num_rows($result) == 1) {
        $register = mysqli_fetch_array($result);
        $nombre = $register['nombre'];
        $apellido = $register['apellido'];
        $telefono = $register['telefono'];
        $mail = $register['mail'];
        $contacto = $register['contacto'];
    }
}

?>

<?php include ("./header.php"); ?>

<div class="container p-4">
    <div class="row">
        <div class="col-4 mx-auto">
            <div class="card" card-body>
            <div class="card-header">Editar Persona</div>
                <form action="./update.php" method="POST">
                    <input type="hidden" name="Id" value="<?PHP echo $Id ?>">
                    <div class="form-group">
                        <div class="mb-3">
                            <label for="nombre">Nombre</label>
                            <input type="text" id="nombre" name="nombre" class="form-control" value="<?PHP echo $nombre ?>" placeholder="Escriba su nombre" autofocus required>
                        </div>
                    
                        <div class="mb-3">
                            <label for="apellido">Apellido</label>
                            <input type="text" name="apellido" class="form-control" value="<?PHP echo $apellido ?>"  required>
                        </div>
                    
                        <div class="mb-3">
                            <label for="telefono">Teléfono</label>
                            <input type="text" name="telefono" class="form-control" value="<?PHP echo $telefono ?>">
                        </div>
                    
                        <div class="mb-3">
                            <label for="mail">E-mail</label>
                            <input type="email" name="mail" class="form-control" value="<?PHP echo $mail ?>">
                        </div>
                        <div class="mb-3">
                            <label for="contacto">contacto</label>
                            <input type="text" name="contacto" class="form-control" value="<?PHP echo $contacto ?>">
                        </div>
                    </div>
                    <input type="submit" class="btn btn-success" name="update" value="Actualizar">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include ("./footer.php"); ?>