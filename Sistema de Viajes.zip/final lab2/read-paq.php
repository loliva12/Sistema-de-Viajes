<!-- Comienza código: read.php -->
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Fecha de Ida</th>
            <th>Fecha de Regreso</th>
            <th>Transporte</th>
            <th>Nombre de Alojamiento</th>
            <th>Excursiones</th>
            <th>Clase</th>
            <th>Lugar</th>
        </tr>
    </thead>
    <tbody>
        <?PHP
            $query = "SELECT p.*, l.nombre nom_lugar
                        FROM PAQUETES p, LUGARES l
                        WHERE p.id_lugar = l.id_lugar";
            $result = mysqli_query($DB_conn, $query);

            while($register = mysqli_fetch_array($result)) { ?>
                <tr onclick="document.location = './edit-paq.php?id_paquetes=<?PHP echo $register['id_paquetes']; ?>'">
                    <td><?PHP echo $register['id_paquetes']; ?></td>
                    <td><?PHP echo $register['nombre']; ?></td>
                    <td><?PHP echo $register['precio']; ?></td>
                    <td><?PHP echo $register['fecha_ida']; ?></td>
                    <td><?PHP echo $register['fecha_vuelta']; ?></td>
                    <td><?PHP echo $register['transporte']; ?></td>
                    <td><?PHP echo $register['nombre_alojamiento']; ?></td>
                    <td><?PHP echo $register['excursiones']; ?></td>
                    <td><?PHP echo $register['clase']; ?></td>
                    <td><?PHP echo $register['nom_lugar']; ?></td>
                    <td>

                        <a href="./edit-paq.php?id_paquetes=<?PHP echo $register['id_paquetes']; ?>" class="btn btn-success" title="Editar el registro <?PHP echo $register['id_paquetes']; ?>">
                            <!-- icono para editar -->
                            <i class="fas fa-user-edit"></i>
                        </a>
                        <a href="./delete-paq.php?id_paquetes=<?PHP echo $register['id_paquetes']; ?>" class="btn btn-danger" title="Borrar el registro <?PHP echo $register['id_paquetes']; ?>">
                            <!-- icono para eliminar -->
                            <i class="fas fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>
               
            <?PHP } ?>

    </tbody>
</table>
