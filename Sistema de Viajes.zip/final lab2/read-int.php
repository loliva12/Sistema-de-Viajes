<!-- Comienza código: read.php -->
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Fecha</th>
            <th>Nombre Paquete</th>
        </tr>
    </thead>
    <tbody>
        <?PHP
            $query = "SELECT max(i.fecha_intereses) fecha_intereses,p.nombre nombre
                        FROM INTERESES i,PAQUETES p
                       WHERE i.id_paquetes=p.id_paquetes
                         AND i.id_usuario=$id_usuario
                         GROUP BY p.nombre
                         ORDER BY p.nombre asc";
            $result = mysqli_query($DB_conn, $query);

            while($register = mysqli_fetch_array($result)) { ?>
                <tr>
                    <td><?PHP echo $register['fecha_intereses']; ?></td>
                    <td><?PHP echo $register['nombre']; ?></td>
                </tr>
            <?PHP } ?>
    </tbody>

</table>
<div class="py-4 bg-light mt-auto">
        <div class="container-fluid px-4">
            <div class="d-flex align-items-center justify-content-between small">
            </div>
        </div>
    </div>
