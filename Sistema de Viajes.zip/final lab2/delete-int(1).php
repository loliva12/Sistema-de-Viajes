<!-- Comienza código: delete.php -->
<?PHP

require_once ("./ludb.php");
$id_usuario = $_GET["id_usuario"];
$id_paquetes = $_GET["id_paquetes"];


if($_GET['id_paquetes']) {

    $query = "DELETE FROM INTERESES
                WHERE id_usuario = $id_usuario
                AND id_paquetes = $id_paquetes";

if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Borrado exitoso")</script>';
  include ("./crud-int.php");
  } else {
    echo "Error deleting record: " . $DB_conn->error;
    exit;
  }            
    
    header("Location: ./crud-int.php");
}

?>


