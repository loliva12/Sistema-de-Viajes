<!-- Comienza código: edit.php -->
<?PHP

include("./ludb.php");

if(isset($_GET['id_paquetes'])) {
    $id_paquetes = $_GET['id_paquetes'];
    $query = "SELECT * FROM PAQUETES
                WHERE id_paquetes = $id_paquetes";
    $result = mysqli_query($DB_conn, $query);

    

    if(mysqli_num_rows($result) == 1) {
        $register = mysqli_fetch_array($result);
        $nombre = $register['nombre'];
        $precio = $register['precio'];
        $fecha_ida = $register['fecha_ida'];
        $fecha_vuelta = $register['fecha_vuelta'];
        $transporte = $register['transporte'];
        $nombre_alojamiento = $register['nombre_alojamiento'];
        $excursiones = $register['excursiones'];
        $clase = $register['clase'];
        $id_lugar = $register['id_lugar'];
    }
}

?>

<?php include ("./header-paq.php"); ?>

<div class="container p-4">
    <div class="row">
        <div class="col-4 mx-auto">
            <div class="card" card-body>
            <div class="card-header">Editar Paquetes</div>
                <form action="./update-paq.php" method="POST">
                    <input type="hidden" name="id_paquetes" value="<?PHP echo $id_paquetes ?>">
                    <div class="form-group">
                    <div class="mb-3">
                            <label for="nombre">Nombre</label>
                            <input type="text" id="nombre" name="nombre" class="form-control" value="<?PHP echo $nombre ?>" placeholder="Ingrese el nombre del paquete" autofocus required>
                        </div>
                        <div class="mb-3">
                            <label for="precio">Precio</label>
                            <input type="number" id="precio" name="precio" class="form-control" value="<?PHP echo $precio ?>" placeholder="Ingrese el precio" autofocus required>
                        </div>
                    
                        <div class="mb-3">
                            <label for="fecha_ida">Fecha de Ida</label>
                            <input type="date" name="fecha_ida" class="form-control" value="<?PHP echo $fecha_ida ?>">
                        </div>
                    
                        <div class="mb-3">
                            <label for="fecha_vuelta">Fecha de regreso</label>
                            <input type="date" name="fecha_vuelta" class="form-control" value="<?PHP echo $fecha_vuelta ?>">
                        </div>
                    
                        <div class="mb-3">
                            <label for="transporte">Transporte</label>
                            <input type="text" name="transporte" class="form-control" value="<?PHP echo $transporte ?>">
                        </div>
                        <div class="mb-3">
                            <label for="nombre_alojamiento">Nombre del alojamiento</label>
                            <input type="text" name="nombre_alojamiento" class="form-control" value="<?PHP echo $nombre_alojamiento ?>">
                        </div>
                        <div class="mb-3">
                            <label for="excursiones">Excursiones</label>
                            <input type="text" name="excursiones" class="form-control" value="<?PHP echo $excursiones ?>">
                        </div>
                        <div class="mb-3">
                            <label for="clase">Clase</label>
                            <input type="text" name="clase" class="form-control" value="<?PHP echo $clase ?>"  placeholder="Ingrese el tipo de clase (Oro, Plata o Bronce)" autofocus required>
                        </div>
                        <div class="mb-3">
                            <label for="id_lugar">Lugar</label>
                            <input type="text" name="id_lugar" class="form-control" value="<?PHP echo $id_lugar ?>">
                        </div>
                    </div>
                    <input type="submit" class="btn btn-success" name="update" value="Actualizar">
                </form>
            </div>
        </div>
    </div>
</div>

<?php include ("./footer-paq.php"); ?>