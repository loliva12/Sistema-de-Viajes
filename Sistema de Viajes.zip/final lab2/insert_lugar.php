<!-- Comienza código: insert.php -->
<?PHP
require_once ("./ludb.php");

$nombre       = $_POST["nombre"];
$descripcion    = $_POST["descripcion"];


$query = "INSERT 
            INTO LUGARES(
                id_lugar, 
                nombre, 
                descripcion)
            VALUE (
                NULL, 
                '$nombre', 
                '$descripcion');";

//echo $query;



if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Registro insertado")</script>';
  include ("./crud_lugar.php");
  } else {
    echo "Error: " . $query . "<br>" . $DB_conn->error;
    exit;
  }

 /*if(!$rs {
    echo "Error: No se pudo insertar en la base de datos MySQL." . NEWLINE;
    echo "Nro de error: " . mysqli_connect_errno() . NEWLINE;
    echo "Mensaje de depuración: " . mysqli_connect_error() . NEWLINE;
    exit;
 }*/

 $_SESSION['message'] = "Éxito: se guardaron correctamente los datos en la base.";
 $_SESSION['message_type'] = "success";

header("Location: ./crud_lugar.php");


?>